# Usage

For usage, please read the package vignette, which is available using `vignette("commonsMath")`.

