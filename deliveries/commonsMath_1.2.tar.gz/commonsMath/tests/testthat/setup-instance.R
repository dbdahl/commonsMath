cat("Starting instance. ********************************\n")
library(rscala)
s <- scala("commonsMath")
